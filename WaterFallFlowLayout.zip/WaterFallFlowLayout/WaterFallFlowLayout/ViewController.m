//
//  ViewController.m
//  WaterFallFlowLayout
//
//  Created by gzy on 2018/2/28.
//  Copyright © 2018年 GZY. All rights reserved.
//

#import "ViewController.h"
#import "WaterFallFlowLayout.h"
#import "WaterFallFlowViewCell.h"
#import "WaterFallFlowModel.h"
#import <MJRefresh.h>
#import "MJExtension.h"

@interface ViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,WaterFallFlowLayoutDelegate>
@property (nonatomic,strong) UICollectionView *collectionView;
@property (nonatomic, strong) NSMutableArray *dataSource;
@end

@implementation ViewController

- (NSMutableArray *)dataSource {
    if (!_dataSource) {
        self.dataSource = [NSMutableArray array];
    }
    return _dataSource;
}

- (UICollectionView *)collectionView {
    if (!_collectionView) {
        //创建一个布局类对象
        WaterFallFlowLayout *layout = [[WaterFallFlowLayout alloc] init];
        layout.itemWidth = (self.view.frame.size.width-3*10)/4;
        layout.minimumLineSpacing = 10;
        layout.minimumInteritemSpacing = 10;
        layout.delegate = self;
        self.collectionView = [[UICollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:layout];
        _collectionView.backgroundColor = [UIColor whiteColor];
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        [_collectionView registerNib:[UINib nibWithNibName:@"WaterFallFlowViewCell" bundle:nil] forCellWithReuseIdentifier:@"cell"];
        _collectionView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            [self loadNewData];
        }];
        
        _collectionView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
            [self loadMoreData];
        }];
    }
    return _collectionView;
}



- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self.view addSubview:self.collectionView];
    //初始刷新
    [self.collectionView.mj_header beginRefreshing];
}
- (void)loadMoreData {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSArray *array = [WaterFallFlowModel objectArrayWithFilename:@"1.plist"];
        [self.dataSource addObjectsFromArray:array];
        //刷新界面
        [self.collectionView reloadData];
        //结束刷新
        [self.collectionView.mj_footer endRefreshing];
    });
    
    
}
- (void)loadNewData {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSArray *array = [WaterFallFlowModel objectArrayWithFilename:@"1.plist"];
        [self.dataSource removeAllObjects];
        [self.dataSource addObjectsFromArray:array];
        //刷新界面
        [self.collectionView reloadData];
        //结束刷新
        [self.collectionView.mj_header endRefreshing];
    });
}
#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    //当数组的个数为0的时候，就不显示上提加载控件，如果数组的个数不为0，就显示上提加载的控件
    self.collectionView.mj_footer.hidden = self.dataSource.count == 0 ? YES : NO ;
    return self.dataSource.count;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    WaterFallFlowViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    [cell configCellWithModel:self.dataSource[indexPath.item]];
    return cell;
}
#pragma mark - WaterFallFlowLayoutDelegate
- (CGFloat)waterFallFlowLayout:(WaterFallFlowLayout *)waterFallFlowLayout heightForItemAtIndexPath:(NSIndexPath *)indexPath width:(CGFloat)width {
    WaterFallFlowModel *model = self.dataSource[indexPath.item];
    return model.h * width / model.w;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
