//
//  WaterFallFlowLayout.h
//  WaterFallFlowLayout
//
//  Created by gzy on 2018/2/28.
//  Copyright © 2018年 Chenxisoft. All rights reserved.
//

#import <UIKit/UIKit.h>
@class WaterFallFlowLayout;
@protocol WaterFallFlowLayoutDelegate <NSObject>
@required
- (CGFloat)waterFallFlowLayout:(WaterFallFlowLayout *)waterFallFlowLayout heightForItemAtIndexPath:(NSIndexPath *)indexPath width:(CGFloat)width;
@end

@interface WaterFallFlowLayout : UICollectionViewLayout
@property (nonatomic,assign)id<WaterFallFlowLayoutDelegate> delegate;

@property (nonatomic,assign)CGFloat minimumLineSpacing;
@property (nonatomic,assign)CGFloat minimumInteritemSpacing;
@property (nonatomic,assign)CGFloat itemWidth;
@property (nonatomic,assign)CGSize headerReferenceSize;
@property (nonatomic,assign)CGSize footerReferenceSize;
@property (nonatomic,assign)UIEdgeInsets sectionInset;

@end
