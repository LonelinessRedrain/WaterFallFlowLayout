//
//  WaterFallFlowLayout.m
//  WaterFallFlowLayout
//
//  Created by gzy on 2018/2/28.
//  Copyright © 2018年 GZY. All rights reserved.
//

#import "WaterFallFlowLayout.h"
#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height

@interface WaterFallFlowLayout ()
@property (nonatomic, strong)NSMutableArray *attributes;//放所有item单元格的布局属性
@property (nonatomic, strong)NSMutableArray *itemHeights;//存放所有列的列高
@end

@implementation WaterFallFlowLayout

- (NSMutableArray *)attributes {
    if (!_attributes) {
        self.attributes = [NSMutableArray array];
    }
    return _attributes;
}

-(NSMutableArray *)itemHeights {
    if (!_itemHeights) {
        self.itemHeights = [NSMutableArray array];
    }
    return _itemHeights;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        //默认设置
        self.itemWidth = kScreenWidth/5;
        self.minimumLineSpacing = 0;
        self.minimumInteritemSpacing = 0;
        self.headerReferenceSize = CGSizeZero;
        self.footerReferenceSize = CGSizeZero;
        self.sectionInset = UIEdgeInsetsZero;
        
    }
    return self;
}
//初始化加载，每次刷新也都会加载
- (void)prepareLayout {
    [super prepareLayout];
    //刷新时清空item属性数组
    [self.attributes removeAllObjects];
    //刷新时清空列高数组
    [self.itemHeights removeAllObjects];
    //添加每列的默认起始高度
    for (int i = 0; i < kScreenWidth/self.itemWidth; i++) {
        [self.itemHeights addObject:@(self.minimumLineSpacing + self.headerReferenceSize.height + self.sectionInset.top)];
    }
    //获取collectionView的所有区数量
    NSUInteger sectionCount = [self.collectionView numberOfSections];
    //获取collectionView的所有单元格数量
    for (int i = 0; i < sectionCount; i++) {
        //获取每个区的单元格数量
        NSUInteger itemCount = [self.collectionView numberOfItemsInSection:i];
        for (int j = 0; j < itemCount; j++) {
            //得到每个单元格布局属性
            UICollectionViewLayoutAttributes *attribute = [self layoutAttributesForItemAtIndexPath:[NSIndexPath indexPathForItem:j inSection:i]];
            //添加进布局属性数组中
            [self.attributes addObject:attribute];
        }
    }
    
}
//返回每个单元格的布局属性
- (UICollectionViewLayoutAttributes *)layoutAttributesForItemAtIndexPath:(NSIndexPath *)indexPath {
    //创建每个单元格的布局属性
    UICollectionViewLayoutAttributes *attribute = [UICollectionViewLayoutAttributes layoutAttributesForCellWithIndexPath:indexPath];
    //计算高height
    CGFloat height = 0;
    if (self.delegate) {
        height = [self.delegate waterFallFlowLayout:self heightForItemAtIndexPath:indexPath width:self.itemWidth];
    }
    //计算坐标x和y,需要找到最小的列高值和列号，所以需要一个数组来存放所有的列高
    //声明一个列号代表我们需要寻找的最小的列高值,默认为0
    NSUInteger minColumn = 0;
    //声明一个最小的列高值，获取第0列的列高值，默认为最小的
    CGFloat minItemHeight = [self.itemHeights[0] floatValue];
    //for循环寻找最小的列高值和列号
    for (int i = 1; i < kScreenWidth/self.itemWidth; i++) {
        CGFloat itemHeight = [self.itemHeights[i] floatValue];
        if (itemHeight < minItemHeight) {
            minItemHeight = itemHeight;
            minColumn = i;
        }
    }
    //for循环结束，最小的列号和列高值就确定了，此时先计算坐标x
    CGFloat x = self.sectionInset.left + minColumn * self.minimumInteritemSpacing + minColumn * self.itemWidth;
    //此时坐标y也就确定了
    CGFloat y;
    //获得列数
    NSUInteger columnCount = kScreenWidth/self.itemWidth;
    if (indexPath.item/columnCount == 0) {
        if (indexPath.section == 0) {
            y = self.headerReferenceSize.height + minItemHeight;
        } else {
            y = minItemHeight;
        }
    } else {
        y = self.minimumLineSpacing + minItemHeight;
    }
    //设置每个单元格的大小
    attribute.frame = CGRectMake(x, y, self.itemWidth, height);
    //更新列高数组中的的高度
    self.itemHeights[minColumn] = @(CGRectGetMaxY(attribute.frame));
    return attribute;
}
//返回布局属性数组
- (NSArray<UICollectionViewLayoutAttributes *> *)layoutAttributesForElementsInRect:(CGRect)rect {
    return self.attributes;
}
//返回集合视图内容大小
- (CGSize)collectionViewContentSize {
    CGFloat maxItemHeight = [self.itemHeights[0] floatValue];
    for (int i = 1; i < kScreenWidth/self.itemWidth; i++) {
        CGFloat height = [self.itemHeights[i] floatValue];
        if (maxItemHeight < height) {
            maxItemHeight = height;
        }
    }
    CGFloat collectionViewHeight = maxItemHeight + self.headerReferenceSize.height + self.footerReferenceSize.height + self.sectionInset.bottom;
    return CGSizeMake(kScreenWidth, collectionViewHeight);
}

@end
