//
//  WaterFallFlowModel.h
//  WaterFallFlowLayout
//
//  Created by gzy on 2018/8/3.
//  Copyright © 2018年 Chenxisoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface WaterFallFlowModel : NSObject
@property (nonatomic,assign) CGFloat w;
@property (nonatomic,assign) CGFloat h;
@property (nonatomic,strong) NSString *img;
@property (nonatomic,strong) NSString *price;
@end
