//
//  WaterFallFlowViewCell.h
//  WaterFallFlowLayout
//
//  Created by gzy on 2018/8/3.
//  Copyright © 2018年 Chenxisoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WaterFallFlowModel.h"
@interface WaterFallFlowViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UILabel *label;
- (void)configCellWithModel:(WaterFallFlowModel *)model;
@end
