//
//  WaterFallFlowViewCell.m
//  WaterFallFlowLayout
//
//  Created by gzy on 2018/8/3.
//  Copyright © 2018年 Chenxisoft. All rights reserved.
//

#import "WaterFallFlowViewCell.h"
#import "UIImageView+WebCache.h"

@implementation WaterFallFlowViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)configCellWithModel:(WaterFallFlowModel *)model {
    NSLog(@"%@",model.img);
    [self.imageView sd_setImageWithURL:[NSURL URLWithString:model.img] placeholderImage:nil];
    self.label.text = model.price;
}

@end
