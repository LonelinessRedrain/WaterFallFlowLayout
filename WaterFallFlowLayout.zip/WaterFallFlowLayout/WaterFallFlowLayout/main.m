//
//  main.m
//  WaterFallFlowLayout
//
//  Created by gzy on 2018/2/28.
//  Copyright © 2018年 GZY. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
